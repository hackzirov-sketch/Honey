
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import Home from './pages/Home';
import Messenger from './pages/Messenger';
import Media from './pages/Media';
import AIAssistant from './pages/AIAssistant';
import Analytics from './pages/Analytics';
import KnowledgeBase from './pages/KnowledgeBase';
import Security from './pages/Security';
import Profile from './pages/Profile';
import Classroom from './pages/Classroom';
import Library from './pages/Library';

const HoneyLogo = ({ size = "sm", scrolled = false }: { size?: "sm" | "lg", scrolled?: boolean }) => {
  const isSmall = size === "sm" || scrolled;
  const hexSize = isSmall ? "w-5 h-6" : "w-10 h-12";
  const gap = isSmall ? "gap-0.5" : "gap-1";
  const mb = isSmall ? "mb-[-0.7rem]" : "lg:mb-[-1.8rem]";
  
  return (
    <div className="flex flex-col items-center select-none group cursor-pointer">
      <div className="flex flex-col items-center animate-float-soft">
        <div className={`flex ${gap} ${mb}`}>
           <div className={`${hexSize} bg-[#FFB800] clip-hexagon shadow-[0_0_25px_#FFB800] group-hover:brightness-125 transition-all duration-500`}></div>
        </div>
        <div className={`flex ${gap} ${mb}`}>
          <div className={`${hexSize} bg-[#E1A200] clip-hexagon transition-all duration-500`}></div>
          <div className={`${hexSize} bg-[#D28100] clip-hexagon transition-all duration-500`}></div>
        </div>
        <div className={`flex ${gap}`}>
          <div className={`${hexSize} bg-[#3E2413] clip-hexagon opacity-60 transition-all duration-500`}></div>
          <div className={`${hexSize} bg-[#3E2413] clip-hexagon opacity-60 transition-all duration-500`}></div>
          <div className={`${hexSize} bg-[#3E2413] clip-hexagon opacity-60 transition-all duration-500`}></div>
        </div>
      </div>
      <div className={`mt-2 text-center transition-all duration-500 ${isSmall ? 'scale-75' : 'scale-100'}`}>
        <span className={`${isSmall ? "text-sm" : "text-4xl"} font-extrabold text-white tracking-[0.3em] uppercase group-hover:text-[#FFB800] transition-colors`}>HONEY</span>
      </div>
    </div>
  );
};

const BottomNav = () => {
  const location = useLocation();
  const navItems = [
    { path: '/', label: 'DASHBOARD', icon: 'fa-shapes' },
    { path: '/messenger', label: 'HUB', icon: 'fa-compass' },
    { path: '/media', label: 'STREAM', icon: 'fa-play-circle' },
    { path: '/classroom', label: 'LIVE', icon: 'fa-podcast' },
    { path: '/library', label: 'BOOKS', icon: 'fa-book-atlas', accent: 'cyan' },
    { path: '/profile', label: 'ME', icon: 'fa-fingerprint' },
  ];

  return (
    <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[200] w-auto max-w-[95vw]">
      <div className="glass-premium rounded-[2.5rem] p-2 flex items-center gap-1 shadow-[0_25px_60px_rgba(0,0,0,0.7)] border-white/10">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const isAccent = item.accent === 'cyan';
          
          return (
            <Link key={item.path} to={item.path} className={`flex flex-col items-center justify-center w-20 h-20 rounded-3xl transition-all duration-300 relative group`}>
               {isActive && (
                 <div className={`absolute inset-0 ${isAccent ? 'bg-cyan-500/20' : 'bg-honey/20'} rounded-3xl border border-white/10 shadow-inner`}></div>
               )}
               <i className={`fas ${item.icon} text-xl ${isActive ? (isAccent ? 'text-cyan-400 drop-shadow-[0_0_12px_#00F0FF]' : 'text-honey drop-shadow-[0_0_12px_#FFB800]') : 'text-gray-400 group-hover:text-white'} transition-all duration-300`}></i>
               
               <span className={`text-[10px] font-black tracking-widest mt-2 text-shadow-premium transition-all duration-300 ${
                 isActive 
                  ? (isAccent ? 'text-cyan-400 opacity-100 scale-105' : 'text-honey opacity-100 scale-105') 
                  : 'text-gray-400 opacity-60 group-hover:opacity-100'
               }`}>
                 {item.label}
               </span>

               {isActive && (
                 <div className={`absolute -bottom-1 w-2 h-2 rounded-full ${isAccent ? 'bg-cyan-400 shadow-[0_0_10px_#00F0FF]' : 'bg-honey shadow-[0_0_10px_#FFB800]'}`}></div>
               )}
            </Link>
          );
        })}
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [user, setUser] = useState<any>(null);
  const [scrolled, setScrolled] = useState(false);
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('honey_theme') as 'dark' | 'light') || 'dark';
  });

  useEffect(() => {
    const savedUser = localStorage.getItem('honey_user');
    if (savedUser) setUser(JSON.parse(savedUser));
    
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    document.documentElement.classList.remove('light', 'dark');
    document.documentElement.classList.add(theme);
    localStorage.setItem('honey_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  };

  return (
    <HashRouter>
      <div className={`min-h-screen flex flex-col transition-colors duration-500`}>
        {/* Elite Floating Top Nav */}
        <div className="fixed top-0 left-0 right-0 z-[100] flex justify-center pointer-events-none">
          <nav className={`transition-all duration-700 pointer-events-auto flex items-center justify-between ${
            scrolled 
              ? 'mt-6 w-[90%] lg:w-[85%] max-w-screen-xl py-4 px-10 glass-premium rounded-[3rem] border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.5)]' 
              : 'mt-0 w-full py-10 px-10 lg:px-20 bg-transparent'
          }`}>
            <Link to="/" className="flex items-center transform transition-all duration-500 hover:scale-105">
              <HoneyLogo size="sm" scrolled={scrolled} />
            </Link>
            
            <div className="flex items-center gap-4 lg:gap-8">
              <button 
                onClick={toggleTheme}
                className="p-3 rounded-2xl glass-premium text-honey hover:scale-110 transition-all border-white/10"
                title={theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
              >
                <i className={`fas ${theme === 'dark' ? 'fa-sun' : 'fa-moon'} text-lg`}></i>
              </button>

              <div className="hidden lg:flex items-center gap-6 mr-4">
                {['ACADEMY', 'COMMUNITY', 'SECURITY'].map((link) => (
                  <span key={link} className="text-[9px] font-black tracking-[0.3em] text-gray-500 hover:text-honey cursor-pointer transition-colors uppercase">
                    {link}
                  </span>
                ))}
              </div>
              
              {user ? (
                <Link to="/profile" className="flex items-center gap-3 glass-premium px-4 py-2 rounded-2xl border-white/10 hover:border-honey/40 transition-all">
                   <div className="w-8 h-8 rounded-xl overflow-hidden border border-white/20">
                      <img src={user.picture} alt="P" className="w-full h-full object-cover" />
                   </div>
                   <span className="hidden sm:inline text-[10px] font-bold text-gray-300 tracking-widest uppercase">{user.name.split(' ')[0]}</span>
                </Link>
              ) : (
                <button className="btn-premium px-8 py-3 text-[10px] rounded-2xl">KIRISH</button>
              )}
            </div>
          </nav>
        </div>

        <main className="flex-1 pt-40 lg:pt-52">
          <Routes>
            <Route path="/" element={<Home onStart={() => {}} />} />
            <Route path="/messenger" element={<Messenger />} />
            <Route path="/media" element={<Media />} />
            <Route path="/classroom" element={<Classroom />} />
            <Route path="/library" element={<Library />} />
            <Route path="/security" element={<Security />} />
            <Route path="/profile" element={<Profile />} />
          </Routes>
        </main>
        
        <BottomNav />
        
        <footer className="py-32 px-10 text-center opacity-40">
           <p className="text-[9px] font-bold tracking-[1.5em] text-gray-500 text-shadow-premium uppercase">HONEY ELITE ECOSYSTEM • 2025</p>
        </footer>
      </div>
    </HashRouter>
  );
};

export default App;
