
import React, { useState, useEffect } from 'react';
import { searchEducationalContent } from '../services/geminiService';

const Library: React.FC = () => {
  const [books, setBooks] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedBook, setSelectedBook] = useState<any | null>(null);

  useEffect(() => {
    const fetchBooks = async () => {
      setIsLoading(true);
      const profile = JSON.parse(localStorage.getItem('honey_profile') || '{}');
      const interest = profile.interest || "Philosophy and Tech";
      const results = await searchEducationalContent(`Professional books for ${interest}`);
      
      const curated = (results.sources || []).map((src: any, i: number) => ({
        id: i,
        title: src.web?.title || `Elite Mastery Vol ${i+1}`,
        author: "Premium Author",
        type: i % 2 === 0 ? 'PDF' : 'AUDIO',
        img: `https://picsum.photos/600/800?random=${i + 100}`,
        description: "Ushbu premium nashr sizning dunyoqarashingizni kengaytirish uchun professional mentorlar tomonidan saralangan.",
        url: src.web?.uri || "#"
      }));

      setBooks(curated);
      setIsLoading(false);
    };
    fetchBooks();
  }, []);

  return (
    <div className="max-w-screen-xl mx-auto px-10 pb-64 animate-fadeIn">
      <header className="mb-24 flex flex-col items-center lg:items-start">
         <div className="inline-flex items-center gap-4 text-cyan-400 mb-6 bg-cyan-500/5 px-6 py-2 rounded-full border border-cyan-500/20">
            <i className="fas fa-book-atlas text-xl icon-3d-prism"></i>
            <span className="text-[10px] font-black uppercase tracking-[0.5em]">The Library of Knowledge</span>
         </div>
         <h1 className="text-6xl lg:text-8xl font-black text-white tracking-tighter uppercase mb-6">ELITE KUTUBXONA</h1>
         <p className="text-gray-500 text-xl font-bold max-w-2xl text-center lg:text-left">Siz uchun maxsus saralangan premium kontentlar markazi.</p>
      </header>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-64">
           <div className="w-16 h-16 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin shadow-[0_0_40px_rgba(0,240,255,0.3)]"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
          {books.map((book) => (
            <div key={book.id} onClick={() => setSelectedBook(book)} className="group cursor-pointer">
              <div className="aspect-[3/4] rounded-[2rem] overflow-hidden mb-8 glass-premium relative group-hover:scale-[1.03] transition-all duration-700 shadow-2xl">
                 <img src={book.img} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" alt={book.title} />
                 <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60"></div>
                 <div className="absolute top-6 right-6 w-12 h-12 bg-white/10 backdrop-blur-xl rounded-xl flex items-center justify-center text-white border border-white/10">
                    <i className={`fas ${book.type === 'AUDIO' ? 'fa-headphones' : 'fa-file-pdf'} text-lg`}></i>
                 </div>
              </div>
              <h4 className="font-black text-xl text-white group-hover:text-cyan-400 transition-colors uppercase tracking-tight truncate px-2">{book.title}</h4>
              <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest mt-2 px-2">{book.author}</p>
            </div>
          ))}
        </div>
      )}

      {/* Elite Studio Modal */}
      {selectedBook && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 animate-fadeIn">
           <div className="absolute inset-0 bg-black/95 backdrop-blur-3xl" onClick={() => setSelectedBook(null)}></div>
           <div className="max-w-5xl w-full glass-premium p-10 lg:p-16 rounded-[4rem] relative z-10 flex flex-col lg:flex-row gap-16 overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-400 to-transparent"></div>
              
              <div className="w-full lg:w-96 aspect-[3/4] rounded-[3rem] overflow-hidden shadow-[0_30px_100px_rgba(0,0,0,0.8)] border border-white/10">
                 <img src={selectedBook.img} className="w-full h-full object-cover" alt={selectedBook.title} />
              </div>
              
              <div className="flex-1 flex flex-col justify-center">
                 <span className="text-cyan-400 font-black text-[10px] tracking-[0.5em] uppercase mb-6 block">{selectedBook.type} EDITION</span>
                 <h2 className="text-5xl lg:text-7xl font-black text-white uppercase tracking-tighter mb-8 leading-none">{selectedBook.title}</h2>
                 <p className="text-gray-400 text-xl leading-relaxed font-bold opacity-70 mb-12">{selectedBook.description}</p>
                 
                 <div className="flex flex-wrap gap-6">
                    <a href={selectedBook.url} target="_blank" rel="noreferrer" className="bg-cyan-500 text-[#1A1100] font-black px-12 py-6 rounded-2xl flex items-center gap-6 shadow-[0_15px_40px_rgba(0,240,255,0.3)] hover:scale-105 transition-all">
                       <i className={`fas ${selectedBook.type === 'AUDIO' ? 'fa-play' : 'fa-book-open'}`}></i>
                       READ NOW
                    </a>
                    <button onClick={() => setSelectedBook(null)} className="glass-premium px-12 py-6 rounded-2xl text-white font-bold hover:bg-white/5">CLOSE</button>
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Library;
